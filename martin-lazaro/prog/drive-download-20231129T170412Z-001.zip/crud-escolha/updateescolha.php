<?php

// Conectar ao BD
include("conecta.php");

//Receber os dados do formulário
$id = $_POST["id"];
$opcao= $_POST['opcao'];

$sql = "UPDATE escolha SET opcao = '$opcao' WHERE id_escolha = $id";

//executar o comando no BD
mysqli_query($connect,$sql);    


?>