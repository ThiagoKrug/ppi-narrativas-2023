<?php

// Receber os dados do formulário
$opcao = $_POST["opcao"];

// conectar ao BD
include("conecta.php");

// Montar o comando SQL
$sql = "INSERT INTO escolha(opcao) values ('$opcao')";

// Executar o comando SQL
mysqli_query($connect, $sql);

?>