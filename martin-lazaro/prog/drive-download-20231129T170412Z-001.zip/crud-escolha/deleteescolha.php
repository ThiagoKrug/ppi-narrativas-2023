<?php

//conectar ao BD
include("conecta.php");

//receber os dados do formulario
$id = $_GET['id'];


$sql = "DELETE FROM escolha WHERE id_escolha= $id";

//executar o comando no BD
mysqli_query($connect, $sql);

?>