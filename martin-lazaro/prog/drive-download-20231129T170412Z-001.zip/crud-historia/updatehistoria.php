<?php

// Conectar ao BD
include("conecta.php");

//Receber os dados do formulário
$id = $_POST["id"];
$texto = $_POST['texto'];

$sql = "UPDATE historia SET texto = '$texto' WHERE id_historia = $id";

//executar o comando no BD
mysqli_query($connect,$sql);    


?>