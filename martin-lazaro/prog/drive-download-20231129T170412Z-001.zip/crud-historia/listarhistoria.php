<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
</head>
<body>
    
<h1> CRUD HISTORIA </h1>

<?php

//Conectar ao BD
include("conecta.php");

//seleciona todos os dados da tabela lista
$sql = "SELECT * FROM historia";

//Executa o select
$resultado = mysqli_query($connect,$sql);

//lista os itens
echo '<table border=1>
<tr>
  <th>ID</th>
  <th>texto</th>
  <th colspan=3>Opções</th>
</tr>';

while ($dados = mysqli_fetch_assoc($resultado)) {
    echo '<tr>';
    echo '<td>'.$dados['id_historia'].'</td>';
    echo '<td>'.$dados['texto'].'</td>';

    echo '<td><a href="deletehistoria?id='.$dados['id_historia'].'&"><img src="imagens/lapis.png" width="20" height"20 title="Editar"></a></td>';
    echo '<td><a href="excluirhistoria?id='.$dados['id_historia'].'"><img src="imagens/lixeira.png" width="20" height"20 title="Excluir"></a></td>';
    echo '</tr>';
}

echo '</table>';

?>

</body>
</html>