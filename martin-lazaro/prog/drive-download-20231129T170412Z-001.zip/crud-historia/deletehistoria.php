<?php

//conectar ao BD
include("conecta.php");

//receber os dados do formulario
$id = $_GET['id'];


$sql = "DELETE FROM historia WHERE id_historia= $id";

//executar o comando no BD
mysqli_query($connect, $sql);

?>