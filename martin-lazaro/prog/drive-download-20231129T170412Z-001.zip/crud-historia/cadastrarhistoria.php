<?php

// Receber os dados do formulário
$texto = $_POST["texto"];

// conectar ao BD
include("conecta.php");

// Montar o comando SQL
$sql = "INSERT INTO historia(texto) values ('$texto')";

// Executar o comando SQL
mysqli_query($connect, $sql);

?>